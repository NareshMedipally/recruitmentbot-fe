import { Component } from '@angular/core';


@Component({
  selector: 'ngx-leaflet',
  styleUrls: ['./leaflet.component.scss'],
  template: `
    <!-- <nb-card>
      <nb-card-header>Leaflet Maps</nb-card-header>
      <nb-card-body>
        <div ></div>
      </nb-card-body>
    </nb-card> -->
  `,
})
export class LeafletComponent {

}
