import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-update-tags',
  templateUrl: './update-tags.component.html',
  styleUrls: ['./update-tags.component.scss']
})
export class UpdateTagsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
