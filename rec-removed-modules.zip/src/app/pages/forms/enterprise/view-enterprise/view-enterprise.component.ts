import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-view-enterprise',
  templateUrl: './view-enterprise.component.html',
  styleUrls: ['./view-enterprise.component.scss']
})
export class ViewEnterpriseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
