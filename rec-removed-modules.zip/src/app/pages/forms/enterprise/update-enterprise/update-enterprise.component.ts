import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-update-enterprise',
  templateUrl: './update-enterprise.component.html',
  styleUrls: ['./update-enterprise.component.scss']
})
export class UpdateEnterpriseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
