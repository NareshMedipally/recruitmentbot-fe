export class technology {

  TotalExperience: any;
  USAExperience: any;
  MarketingPhoneNumber: any;
  MarketingEmailID: any;
  MarketingLinkedInProfile: any;
  LookingForJob: any;
  SubjectTag: any;
  NonSubTags: any;
  Tags: any;
  Resume: any;
  Certification: any;
  EmailTemplate: any;
}
