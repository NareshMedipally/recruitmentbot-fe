import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-email-auth',
  templateUrl: './email-auth.component.html',
  styleUrls: ['./email-auth.component.scss']
})
export class EmailAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
